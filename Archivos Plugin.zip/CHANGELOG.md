# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com), and this
project adheres to [Semantic Versioning](https://semver.org).

## [0.2.0] - 2024-02-02

### Added
- 
### Changed

### Removed

## [0.1.1] - 2024-02-05
### Added
- Instalación de libreria Svelte y ajuste de configuraciónes en tsconfig.json y esbuild.cong.mjs 


## [0.1.0] - 2024-02-02
### Added
- Inicialización del proyecto. 
- Configuración de Git, conexión y sincronización con github.
- Creación de la base de archivos: main.ts en src/
- Instalación de dependencias.
- Configuración de esbuild para compilación
- Testeo inicial en bóveda Prueba
- Documentación en el changelog
