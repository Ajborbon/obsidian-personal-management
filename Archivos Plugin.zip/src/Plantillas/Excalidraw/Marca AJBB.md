---

excalidraw-plugin: parsed
tags: [excalidraw]
---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.1.6",
	"elements": [
		{
			"id": "hw_eGnXjU_jh2WCjn7Fs2",
			"type": "rectangle",
			"x": -343.935546875,
			"y": -220.2666244506836,
			"width": 238.10528564453125,
			"height": 170.3040771484375,
			"angle": 0,
			"strokeColor": "#fec82a",
			"backgroundColor": "#05394e",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1467915422,
			"version": 30,
			"versionNonce": 507100510,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1714080893401,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#f2f2f2",
		"currentItemStrokeColor": "#fec82a",
		"currentItemBackgroundColor": "#05394e",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 4,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 753.7261352539062,
		"scrollY": 525.40283203125,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"gridColor": {
			"Bold": "#BCBCBCFF",
			"Regular": "#E0E0E0FF"
		},
		"colorPalette": {
			"topPicks": {
				"canvasBackground": [
					"#848484",
					"#f2f2f2",
					"#05394e",
					"#fec82a",
					"#1e1e1e"
				],
				"elementBackground": [
					"#848484",
					"#f2f2f2",
					"#05394e",
					"#fec82a",
					"#1e1e1e"
				],
				"elementStroke": [
					"#848484",
					"#f2f2f2",
					"#05394e",
					"#fec82a",
					"#1e1e1e"
				]
			}
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		},
		"objectsSnapModeEnabled": false
	},
	"files": {}
}
```
%%