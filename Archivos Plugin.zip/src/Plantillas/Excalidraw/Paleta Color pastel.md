---

excalidraw-plugin: parsed
tags: [excalidraw]
---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.1.6",
	"elements": [],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#FFAAAA",
		"currentItemBackgroundColor": "#55AA55",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 2,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 4,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 753.7261352539062,
		"scrollY": 525.40283203125,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"colorPalette": {
			"topPicks": {
				"canvasBackground": [
					"#FFAAAA",
					"#FFDDAA",
					"#738CA6",
					"#88CC88",
					"#55AA55"
				],
				"elementBackground": [
					"#FFAAAA",
					"#FFDDAA",
					"#738CA6",
					"#88CC88",
					"#55AA55"
				],
				"elementStroke": [
					"#FFAAAA",
					"#FFDDAA",
					"#738CA6",
					"#88CC88",
					"#55AA55"
				]
			}
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		},
		"objectsSnapModeEnabled": false
	},
	"files": {}
}
```
%%