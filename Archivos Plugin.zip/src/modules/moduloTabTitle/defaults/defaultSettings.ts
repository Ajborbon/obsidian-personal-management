// src/modules/moduloTabTitle/defaults/defaultSettings.ts
import { TabTitleSettings } from '../interfaces/TabTitleSettings';

export const DEFAULT_TAB_SETTINGS: TabTitleSettings = {
    titleDisplayMode: 'filename'
};