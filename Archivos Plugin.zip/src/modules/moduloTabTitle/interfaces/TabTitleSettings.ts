// src/modules/moduloTabTitle/interfaces/TabTitleSettings.ts
export interface TabTitleSettings {
    titleDisplayMode: 'alias' | 'title' | 'filename';
}